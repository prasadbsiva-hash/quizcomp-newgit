import React, { useEffect } from "react";
import axios from "axios";

export default function Payment() {
  useEffect(() => {
    const initiatePayment = async () => {
      const token = localStorage.getItem("token");
      const res = await axios.post("/api/payment/initiate", { userId: token });
      // Use Razorpay checkout here...
    };
    initiatePayment();
  }, []);

  return <div>Payment processing...</div>;
}