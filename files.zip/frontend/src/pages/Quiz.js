import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Quiz() {
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState([]);

  useEffect(() => {
    const fetchQuiz = async () => {
      const token = localStorage.getItem("token");
      // Assume age is stored, otherwise prompt for age
      const res = await axios.post("/api/quiz/generate", { userId: token, age: 10 });
      setQuiz(res.data);
    };
    fetchQuiz();
  }, []);

  const submitQuiz = async () => {
    const token = localStorage.getItem("token");
    await axios.post("/api/quiz/submit", { userId: token, quizId: quiz._id, answers });
    window.location = "/winners";
  };

  if (!quiz) return <div>Loading quiz...</div>;

  return (
    <div>
      {quiz.questions.map((q, idx) => (
        <div key={idx}>
          <p>{q.question}</p>
          <input type="text" onChange={e => {
            const newAns = [...answers];
            newAns[idx] = e.target.value;
            setAnswers(newAns);
          }} />
        </div>
      ))}
      <button onClick={submitQuiz}>Submit Quiz</button>
    </div>
  );
}