import React, { useState } from "react";
import axios from "axios";

export default function Login() {
  const [mobile, setMobile] = useState("");
  const [otp, setOTP] = useState("");
  const [step, setStep] = useState(1);

  const sendOTP = async () => {
    await axios.post("/api/auth/send-otp", { mobile });
    setStep(2);
  };

  const verifyOTP = async () => {
    const res = await axios.post("/api/auth/verify-otp", { mobile, otp });
    localStorage.setItem("token", res.data.token);
    window.location = "/payment";
  };

  return (
    <div>
      {step === 1 ? (
        <div>
          <input type="text" value={mobile} onChange={e => setMobile(e.target.value)} placeholder="Mobile Number" />
          <button onClick={sendOTP}>Send OTP</button>
        </div>
      ) : (
        <div>
          <input type="text" value={otp} onChange={e => setOTP(e.target.value)} placeholder="Enter OTP" />
          <button onClick={verifyOTP}>Verify & Continue</button>
        </div>
      )}
    </div>
  );
}