const mongoose = require("mongoose");
const QuizSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  questions: Array,
  score: Number,
  completed: { type: Boolean, default: false },
});
module.exports = mongoose.model("Quiz", QuizSchema);