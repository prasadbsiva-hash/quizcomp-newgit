const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema({
  mobile: { type: String, unique: true },
  age: Number,
  registered: { type: Boolean, default: false },
  prize: Number,
});
module.exports = mongoose.model("User", UserSchema);