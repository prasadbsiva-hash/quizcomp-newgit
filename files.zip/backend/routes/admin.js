const express = require("express");
const router = express.Router();
const Quiz = require("../models/Quiz");
const User = require("../models/User");
const Payment = require("../models/Payment");

// Get top 3 winners
router.get("/winners", async (req, res) => {
  const quizzes = await Quiz.find({ completed: true }).sort({ score: -1 }).limit(3).populate("user");
  const prizes = [1000, 500, 300];
  quizzes.forEach((q, i) => {
    // update the user with prize amount
    User.findByIdAndUpdate(q.user._id, { prize: prizes[i] });
  });
  res.json(quizzes);
});

module.exports = router;