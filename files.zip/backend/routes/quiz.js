const express = require("express");
const router = express.Router();
const Quiz = require("../models/Quiz");
const { generateQuiz } = require("../utils/quiz-ai");

router.post("/generate", async (req, res) => {
  const { userId, age } = req.body;
  const quizData = await generateQuiz(age); // uses OpenAI or local ML
  const quiz = await Quiz.create({ user: userId, questions: quizData });
  res.json(quiz);
});

router.post("/submit", async (req, res) => {
  const { userId, quizId, answers } = req.body;
  // Evaluate & score
  const quiz = await Quiz.findById(quizId);
  // scoring logic...
  quiz.score = calculateScore(quiz.questions, answers);
  quiz.completed = true;
  await quiz.save();
  res.json({ score: quiz.score });
});

module.exports = router;