const express = require("express");
const router = express.Router();
const Razorpay = require("razorpay");
const Payment = require("../models/Payment");
const User = require("../models/User");

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY,
  key_secret: process.env.RAZORPAY_SECRET,
});

// Initiate payment
router.post("/initiate", async (req, res) => {
  const { userId } = req.body;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ error: "User not found" });

  const order = await razorpay.orders.create({
    amount: 3000, // ₹30 in paise
    currency: "INR",
    receipt: `receipt_${Date.now()}`,
  });
  await Payment.create({ user: userId, orderId: order.id, amount: 30, status: "pending" });
  res.json({ orderId: order.id, razorpayKey: process.env.RAZORPAY_KEY });
});

// Webhook for payment success (from Razorpay)
router.post("/verify", async (req, res) => {
  const { orderId, paymentId, signature } = req.body;
  // Verify signature here...
  const payment = await Payment.findOneAndUpdate({ orderId }, { paymentId, status: "paid" });
  await User.findByIdAndUpdate(payment.user, { registered: true });
  res.json({ success: true });
});

module.exports = router;