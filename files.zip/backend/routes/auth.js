const express = require("express");
const router = express.Router();
const User = require("../models/User");
const jwt = require("jsonwebtoken");
const { sendOTP, verifyOTP } = require("../utils/otp");

// Step 1: Send OTP
router.post("/send-otp", async (req, res) => {
  const { mobile } = req.body;
  await sendOTP(mobile);
  res.json({ success: true, message: "OTP sent" });
});

// Step 2: Verify OTP & Register/Login
router.post("/verify-otp", async (req, res) => {
  const { mobile, otp } = req.body;
  const valid = await verifyOTP(mobile, otp);
  if (!valid) return res.status(400).json({ error: "Invalid OTP" });

  let user = await User.findOne({ mobile });
  if (!user) user = await User.create({ mobile });

  const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
  res.json({ token, user });
});

module.exports = router;